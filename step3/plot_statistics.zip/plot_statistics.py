
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Project paths
BASE_DIR = Path(__file__).resolve().parent
CSV_PATH = BASE_DIR / "results" / "dataset_statistics.csv"
PLOT_DIR = BASE_DIR / "results" / "plots"

# Create plots directory if it does not exist
PLOT_DIR.mkdir(parents=True, exist_ok=True)

# Read statistics
df = pd.read_csv(CSV_PATH)

# Select only fruit classes (exclude ALL_CLASSES)
fruit_df = df[
    (df["Split"] == "train") &
    (df["Class"] != "ALL_CLASSES")
].copy()

fruits = fruit_df["Class"].tolist()

# ---------------------------------
# 1. Mean RGB values
# ---------------------------------

x = np.arange(len(fruits))
width = 0.25

plt.figure(figsize=(10, 6))

plt.bar(x - width, fruit_df["Mean_R"], width, label="Red")
plt.bar(x, fruit_df["Mean_G"], width, label="Green")
plt.bar(x + width, fruit_df["Mean_B"], width, label="Blue")

plt.xticks(x, fruits)
plt.xlabel("Fruit Classes")
plt.ylabel("Mean Pixel Value")
plt.title("Mean RGB Values by Fruit Class (Train)")
plt.legend()
plt.tight_layout()

plt.savefig(PLOT_DIR / "mean_rgb.png", dpi=300)
plt.show()
plt.close()


# ---------------------------------
# 2. Variance RGB values
# ---------------------------------

plt.figure(figsize=(10, 6))

plt.bar(x - width, fruit_df["Variance_R"], width, label="Red")
plt.bar(x, fruit_df["Variance_G"], width, label="Green")
plt.bar(x + width, fruit_df["Variance_B"], width, label="Blue")

plt.xticks(x, fruits)
plt.xlabel("Fruit Classes")
plt.ylabel("Pixel Variance")
plt.title("RGB Variance by Fruit Class (Train)")
plt.legend()
plt.tight_layout()

plt.savefig(PLOT_DIR / "variance_rgb.png", dpi=300)
plt.show()
plt.close()


# ---------------------------------
# 3. Image counts by dataset split
# ---------------------------------

splits = ["train", "validation", "test"]
classes = ["Apple", "Banana", "Pomegranate", "Watermelon"]

count_data = []

for split in splits:
    split_df = df[
        (df["Split"] == split) &
        (df["Class"] != "ALL_CLASSES")
    ]

    count_data.append([
        split_df.loc[
            split_df["Class"] == fruit, "Image_Count"
        ].iloc[0]
        for fruit in classes
    ])

count_array = np.array(count_data)

x = np.arange(len(classes))
width = 0.25

plt.figure(figsize=(10, 6))

for i, split in enumerate(splits):
    plt.bar(
        x + (i - 1) * width,
        count_array[i],
        width,
        label=split.capitalize()
    )

plt.xticks(x, classes)
plt.xlabel("Fruit Classes")
plt.ylabel("Number of Images")
plt.title("Image Distribution Across Dataset Splits")
plt.legend()
plt.tight_layout()

plt.savefig(PLOT_DIR / "image_distribution.png", dpi=300)
plt.show()
plt.close()

print("All charts created successfully!")
print(f"Charts saved in: {PLOT_DIR}")
