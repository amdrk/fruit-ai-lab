
from pathlib import Path
import json
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf

from tensorflow.keras import layers, models
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    ConfusionMatrixDisplay
)

# =====================================
# 1. تنظیمات اولیه
# =====================================

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data" / "processed"
MODEL_DIR = BASE_DIR / "models"

MODEL_DIR.mkdir(exist_ok=True)

CLASSES = [
    "Apple",
    "Banana",
    "Pomegranate",
    "Watermelon"
]

IMAGE_SIZE = (128, 128)
BATCH_SIZE = 16
EPOCHS = 30
SEED = 42

tf.keras.utils.set_random_seed(SEED)

# =====================================
# 2. بارگذاری تصاویر
# =====================================

train_ds = tf.keras.utils.image_dataset_from_directory(
    DATA_DIR / "train",
    class_names=CLASSES,
    image_size=IMAGE_SIZE,
    batch_size=BATCH_SIZE,
    label_mode="int",
    shuffle=True,
    seed=SEED
)

val_ds = tf.keras.utils.image_dataset_from_directory(
    DATA_DIR / "validation",
    class_names=CLASSES,
    image_size=IMAGE_SIZE,
    batch_size=BATCH_SIZE,
    label_mode="int",
    shuffle=False
)

test_ds = tf.keras.utils.image_dataset_from_directory(
    DATA_DIR / "test",
    class_names=CLASSES,
    image_size=IMAGE_SIZE,
    batch_size=BATCH_SIZE,
    label_mode="int",
    shuffle=False
)

print("\nClass names:", train_ds.class_names)

# بهینه‌سازی بارگذاری داده
AUTOTUNE = tf.data.AUTOTUNE

train_ds = train_ds.prefetch(buffer_size=AUTOTUNE)
val_ds = val_ds.prefetch(buffer_size=AUTOTUNE)
test_ds = test_ds.prefetch(buffer_size=AUTOTUNE)

# =====================================
# 3. افزایش تنوع تصاویر (Data Augmentation)
# =====================================

data_augmentation = models.Sequential([
    layers.RandomFlip("horizontal"),
    layers.RandomRotation(0.08),
    layers.RandomZoom(0.10)
], name="data_augmentation")

# =====================================
# 4. طراحی شبکه عصبی CNN
# =====================================

model = models.Sequential([

    layers.Input(shape=(128, 128, 3)),

    # افزایش تنوع داده در زمان آموزش
    data_augmentation,

    # نرمال‌سازی مقادیر پیکسل‌ها به بازه صفر تا یک
    layers.Rescaling(1.0 / 255),

    # بلوک کانولوشن اول
    layers.Conv2D(
        32, (3, 3),
        activation="relu",
        padding="same"
    ),
    layers.MaxPooling2D((2, 2)),

    # بلوک کانولوشن دوم
    layers.Conv2D(
        64, (3, 3),
        activation="relu",
        padding="same"
    ),
    layers.MaxPooling2D((2, 2)),

    # بلوک کانولوشن سوم
    layers.Conv2D(
        128, (3, 3),
        activation="relu",
        padding="same"
    ),
    layers.MaxPooling2D((2, 2)),

    # تبدیل ویژگی‌ها به بردار
    layers.GlobalAveragePooling2D(),

    # لایه متراکم
    layers.Dense(128, activation="relu"),

    # جلوگیری از بیش‌برازش
    layers.Dropout(0.4),

    # چهار خروجی برای چهار میوه
    layers.Dense(4, activation="softmax")

], name="Fruit_CNN")

# =====================================
# 5. تنظیم فرایند آموزش
# =====================================

model.compile(
    optimizer=tf.keras.optimizers.Adam(
        learning_rate=0.001
    ),
    loss="sparse_categorical_crossentropy",
    metrics=["accuracy"]
)

# نمایش ساختار مدل
model.summary()

# =====================================
# 6. تنظیم کنترل آموزش
# =====================================

early_stopping = EarlyStopping(
    monitor="val_loss",
    patience=7,
    restore_best_weights=True
)

checkpoint = ModelCheckpoint(
    filepath=str(MODEL_DIR / "best_fruit_model.keras"),
    monitor="val_loss",
    save_best_only=True
)

# =====================================
# 7. آموزش مدل
# =====================================

history = model.fit(
    train_ds,
    validation_data=val_ds,
    epochs=EPOCHS,
    callbacks=[
        early_stopping,
        checkpoint
    ]
)




# Save training history

import pandas as pd

RESULT_DIR = BASE_DIR / "results"
RESULT_DIR.mkdir(parents=True, exist_ok=True)

history_df = pd.DataFrame(history.history)

history_df.to_csv(
    RESULT_DIR / "training_history.csv",
    index=False,
    encoding="utf-8-sig"
)

print("Training history saved successfully!")




# ذخیره مدل نهایی
model.save(MODEL_DIR / "fruit_model.keras")

# ذخیره نام کلاس‌ها
with open(
    MODEL_DIR / "class_names.json",
    "w",
    encoding="utf-8"
) as file:
    json.dump(CLASSES, file, ensure_ascii=False, indent=4)

print("\nModel training completed!")

# =====================================
# 8. رسم نمودار دقت
# =====================================

plt.figure(figsize=(8, 5))

plt.plot(
    history.history["accuracy"],
    label="Training Accuracy"
)

plt.plot(
    history.history["val_accuracy"],
    label="Validation Accuracy"
)

plt.title("Model Accuracy")
plt.xlabel("Epoch")
plt.ylabel("Accuracy")
plt.legend()
plt.grid()
plt.savefig(
    MODEL_DIR / "accuracy.png",
    dpi=150
)
plt.show()

# =====================================
# 9. رسم نمودار خطا
# =====================================

plt.figure(figsize=(8, 5))

plt.plot(
    history.history["loss"],
    label="Training Loss"
)

plt.plot(
    history.history["val_loss"],
    label="Validation Loss"
)

plt.title("Model Loss")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.legend()
plt.grid()
plt.savefig(
    MODEL_DIR / "loss.png",
    dpi=150
)
plt.show()

# =====================================
# 10. ارزیابی نهایی روی Test
# =====================================

test_loss, test_accuracy = model.evaluate(test_ds)

print("\nTest Results")
print("------------------------")
print(f"Test Loss: {test_loss:.4f}")
print(f"Test Accuracy: {test_accuracy:.4f}")

# =====================================
# 11. محاسبه معیارهای ارزیابی
# =====================================

y_true = []
y_pred = []

for images, labels in test_ds:

    predictions = model.predict(
        images,
        verbose=0
    )

    predicted_labels = np.argmax(
        predictions,
        axis=1
    )

    y_true.extend(labels.numpy())
    y_pred.extend(predicted_labels)

print("\nClassification Report:")
print(
    classification_report(
        y_true,
        y_pred,
        labels=list(range(len(CLASSES))),
        target_names=CLASSES,
        zero_division=0
    )
)

# =====================================
# 12. رسم ماتریس درهم‌ریختگی
# =====================================

cm = confusion_matrix(
    y_true,
    y_pred,
    labels=list(range(len(CLASSES)))
)

display = ConfusionMatrixDisplay(
    confusion_matrix=cm,
    display_labels=CLASSES
)

display.plot(
    cmap="Blues",
    xticks_rotation=30
)

plt.title("Fruit Classification Confusion Matrix")
plt.tight_layout()

# Save confusion matrix
plt.savefig(
    RESULT_DIR / "plots" / "confusion_matrix.png",
    dpi=300,
    bbox_inches="tight"
)

plt.show()

print("\nAll evaluation steps completed!")
print(f"Model files saved in: {MODEL_DIR}")
