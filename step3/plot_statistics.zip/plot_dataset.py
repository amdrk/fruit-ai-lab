from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

# مسیر اصلی پروژه
BASE_DIR = Path(__file__).resolve().parent

# مسیر فایل اطلاعات دیتاست
CSV_PATH = BASE_DIR / "dataset_info.csv"

# مسیر ذخیره نمودار
OUTPUT_DIR = BASE_DIR / "results" / "plots"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# خواندن اطلاعات
df = pd.read_csv(CSV_PATH)

# فقط اطلاعات مجموعه آموزش
train_data = df[df["Split"] == "train"]

# رسم نمودار
plt.figure(figsize=(9, 5))

plt.bar(
    train_data["Class"],
    train_data["Image_Count"]
)

plt.title("Number of Training Images per Fruit Class")
plt.xlabel("Fruit Class")
plt.ylabel("Number of Images")

plt.grid(axis="y", alpha=0.3)
plt.tight_layout()

# ذخیره نمودار
plt.savefig(
    OUTPUT_DIR / "class_distribution.png",
    dpi=150
)

plt.show()

print("Class distribution chart saved successfully!")