
# Dataset Documentation

## 1. Project Title
Fruit Image Classification Using Supervised Learning

## 2. Dataset Source
The images were collected from the
Fruit and Vegetable Image Recognition dataset
available on images.cv.

Source:
https://images.cv/data-sources/fruit-and-vegetable-image-recognition

## 3. Dataset Classes
The dataset contains four fruit classes:

1. Banana
2. Watermelon
3. Pomegranate
4. Apple

## 4. Dataset Size
The target dataset contains approximately
320 images.

Each class contains approximately 80 images.

## 5. Data Splitting
The dataset is divided into:

- Training: 70%
- Validation: 15%
- Testing: 15%

## 6. Image Preprocessing
The following preprocessing operations are applied:

- Checking image validity
- Converting images to RGB
- Resizing images to 128x128 pixels
- Organizing images into class folders

## 7. Learning Method
This project uses supervised learning.

Each image has a label corresponding
to its fruit category.

## 8. Dataset License
The source page identifies the dataset
as CC0 Public Domain.

The license information of each downloaded
dataset should also be checked and recorded.

## 9. Dataset Limitations
The dataset is relatively small.
The number of images per class is limited.
The model may not generalize well to
all real-world lighting conditions,
backgrounds, and camera angles.

## 10. Model Architecture

A Convolutional Neural Network (CNN)
is used for fruit image classification.

The model includes:

- Convolutional layers
- Max pooling layers
- Global average pooling
- Dense layers
- Dropout
- Softmax output layer

## 11. Training Configuration

- Image size: 128x128
- Batch size: 16
- Maximum epochs: 30
- Optimizer: Adam
- Loss function: Sparse Categorical Crossentropy
- Evaluation metrics: Accuracy, Precision, Recall, F1-score

## 12. Model Evaluation

The model is evaluated using a separate
test dataset.

Accuracy, classification report,
and confusion matrix are used
to evaluate its performance.