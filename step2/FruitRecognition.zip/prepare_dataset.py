
from pathlib import Path
from PIL import Image
import random
import shutil

# مسیر اصلی پروژه
BASE_DIR = Path(__file__).resolve().parent

# محل تصاویر اصلی
RAW_DIR = BASE_DIR / "data" / "raw"

# محل ذخیره دیتاست تقسیم شده
OUTPUT_DIR = BASE_DIR / "data" / "processed"

# چهار کلاس موردنظر
CLASSES = [
    "Banana",
    "Watermelon",
    "Pomegranate",
    "Apple"
]

# پسوندهای مجاز تصاویر
VALID_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}

# تنظیمات تقسیم داده
TRAIN_RATIO = 0.70
VAL_RATIO = 0.15

# برای اینکه تقسیم داده در اجراهای بعدی ثابت بماند
random.seed(42)


def is_valid_image(image_path):
    """بررسی سالم بودن فایل تصویر"""

    try:
        with Image.open(image_path) as img:
            img.verify()
        return True

    except Exception:
        return False


def prepare_dataset():

    print("Starting dataset preparation...\n")

    # بررسی وجود پوشه تصاویر
    if not RAW_DIR.exists():
        raise FileNotFoundError(
            f"Raw dataset folder not found: {RAW_DIR}"
        )

    # بررسی پوشه‌های چهار کلاس
    for class_name in CLASSES:

        class_dir = RAW_DIR / class_name

        if not class_dir.exists():
            raise FileNotFoundError(
                f"Missing class folder: {class_name}"
            )

    # پاک کردن خروجی قبلی برای جلوگیری از ترکیب داده‌های قدیمی
    if OUTPUT_DIR.exists():
        shutil.rmtree(OUTPUT_DIR)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    total_images = 0

    for class_name in CLASSES:

        class_dir = RAW_DIR / class_name

        # پیدا کردن تصاویر
        image_files = [
            file for file in class_dir.iterdir()
            if file.is_file()
            and file.suffix.lower() in VALID_EXTENSIONS
        ]

        # حذف تصاویر خراب
        valid_images = []

        for image_path in image_files:

            if is_valid_image(image_path):
                valid_images.append(image_path)
            else:
                print(f"Invalid image skipped: {image_path.name}")

        # بررسی حداقل تعداد تصاویر
        if len(valid_images) < 10:
            raise ValueError(
                f"Not enough valid images for {class_name}. "
                f"Found: {len(valid_images)}"
            )

        # مخلوط کردن تصاویر
        random.shuffle(valid_images)

        n = len(valid_images)

        train_end = int(n * TRAIN_RATIO)
        val_end = train_end + int(n * VAL_RATIO)

        train_images = valid_images[:train_end]
        val_images = valid_images[train_end:val_end]
        test_images = valid_images[val_end:]

        splits = {
            "train": train_images,
            "validation": val_images,
            "test": test_images
        }

        print(f"\nClass: {class_name}")
        print(f"Total valid images: {n}")

        for split_name, images in splits.items():

            destination = (
                OUTPUT_DIR / split_name / class_name
            )

            destination.mkdir(
                parents=True,
                exist_ok=True
            )

            for image_path in images:

                shutil.copy2(
                    image_path,
                    destination / image_path.name
                )

            print(f"{split_name}: {len(images)} images")

        total_images += n

    print("\n------------------------------")
    print("Dataset preparation completed!")
    print(f"Total images: {total_images}")
    print(f"Output folder: {OUTPUT_DIR}")
    print("------------------------------")


if __name__ == "__main__":
    prepare_dataset()