# Final Project Results
## Fruit Image Classification Using CNN

### 1. Project Objective

The objective of this project is to design and implement a supervised learning system capable of classifying fruit images into four categories:

- Apple
- Banana
- Pomegranate
- Watermelon

### 2. Learning Method

Supervised Learning was used to train the classification model. Each training image was associated with a predefined class label.

### 3. Dataset

The dataset contains four fruit classes. The images were divided into three subsets:

- Training
- Validation
- Testing

Each class contains 80 images in total.

### 4. Model Architecture

A Convolutional Neural Network (CNN) was implemented using TensorFlow and Keras.

The architecture includes:

- Convolutional layers
- Max Pooling layers
- Global Average Pooling
- Dense layers
- Dropout
- Softmax output layer

### 5. Training Configuration

| Parameter | Value |
|---|---|
| Image size | 128 × 128 |
| Batch size | 16 |
| Maximum epochs | 30 |
| Optimizer | Adam |
| Learning rate | 0.001 |
| Loss function | Sparse Categorical Crossentropy |
| Number of classes | 4 |

### 6. Evaluation Results

The model achieved the following results on the test dataset:

- Test Loss: 0.8506
- Test Accuracy: 68.75%

Classification metrics:

| Class | Precision | Recall | F1-score |
|---|---:|---:|---:|
| Apple | 0.70 | 0.58 | 0.64 |
| Banana | 0.75 | 1.00 | 0.86 |
| Pomegranate | 0.57 | 0.67 | 0.62 |
| Watermelon | 0.75 | 0.50 | 0.60 |


### 7. Real Image Prediction

The trained CNN model was tested using
an additional image that was not part
of the training, validation, or test datasets.

Prediction result:

- Predicted Class: Banana
- Confidence Score: 63.36%

Class scores:

- Apple: 7.25%
- Banana: 63.36%
- Pomegranate: 21.85%
- Watermelon: 7.53%

The model classified the input image
as Banana.

### 8. Final Conclusion

The project successfully implemented
a supervised CNN-based fruit
classification system for four fruit classes.

The model achieved 68.75% test accuracy
and successfully performed an additional
prediction on a new fruit image.


### 8. Conclusion

The CNN model successfully learned to classify images into four fruit categories.

The best classification performance was achieved for Banana, while Watermelon had the lowest recall.

The final test accuracy was 68.75%.

The results demonstrate that a CNN-based supervised learning approach can be used for fruit image classification, although the model's performance can be improved through additional training data and more advanced architectures.