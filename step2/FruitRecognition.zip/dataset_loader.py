
from pathlib import Path
from PIL import Image
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# مسیر پروژه
BASE_DIR = Path(__file__).resolve().parent

# مسیر دیتاست آماده
DATA_DIR = BASE_DIR / "data" / "processed"

CLASSES = [
    "Banana",
    "Watermelon",
    "Pomegranate",
    "Apple"
]

SPLITS = ["train", "validation", "test"]

IMAGE_SIZE = (128, 128)

VALID_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def load_split(split_name):

    images = []
    labels = []

    split_dir = DATA_DIR / split_name

    if not split_dir.exists():
        raise FileNotFoundError(
            f"Split folder not found: {split_dir}"
        )

    for class_name in CLASSES:

        class_dir = split_dir / class_name

        if not class_dir.exists():
            raise FileNotFoundError(
                f"Class folder not found: {class_dir}"
            )

        for image_path in class_dir.iterdir():

            if (
                not image_path.is_file()
                or image_path.suffix.lower() not in VALID_EXTENSIONS
            ):
                continue

            try:
                with Image.open(image_path) as img:

                    # تبدیل تصویر به RGB
                    img = img.convert("RGB")

                    # یکسان‌سازی اندازه تصاویر
                    img = img.resize(IMAGE_SIZE)

                    # تبدیل تصویر به آرایه
                    image_array = np.asarray(
                        img,
                        dtype=np.uint8
                    )

                    images.append(image_array)
                    labels.append(class_name)

            except Exception as error:
                print(
                    f"Could not load {image_path}: {error}"
                )

    if not images:
        raise ValueError(
            f"No images loaded from {split_name}"
        )

    X = np.stack(images)
    y = np.array(labels)

    return X, y



def main():

    print("Loading dataset...\n")

    dataset_report = []

    for split_name in SPLITS:

        X, y = load_split(split_name)

        print(f"\nSplit: {split_name}")
        print(f"Images shape: {X.shape}")
        print(f"Labels shape: {y.shape}")

        # نمایش تعداد تصاویر هر کلاس
        for class_name in CLASSES:

            count = int(np.sum(y == class_name))

            print(f"{class_name}: {count}")

            dataset_report.append({
                "Split": split_name,
                "Class": class_name,
                "Image_Count": count
            })

        # ساخت یک پنجره با چهار تصویر
        fig, axes = plt.subplots(2, 2, figsize=(9, 8))

        fig.suptitle(
            f"Sample Images - {split_name.upper()}",
            fontsize=16
        )

        for i, class_name in enumerate(CLASSES):

            # پیدا کردن اولین تصویر از هر کلاس
            indices = np.where(y == class_name)[0]

            if len(indices) == 0:
                print(f"No image found for {class_name}")
                continue

            image_index = indices[0]

            ax = axes.flat[i]

            ax.imshow(X[image_index])
            ax.set_title(class_name)
            ax.axis("off")

        plt.tight_layout()
        plt.show()

    # ذخیره گزارش تعداد تصاویر
    report_df = pd.DataFrame(dataset_report)

    report_path = BASE_DIR / "dataset_info.csv"

    report_df.to_csv(
        report_path,
        index=False,
        encoding="utf-8-sig"
    )

    print("\nDataset loading completed!")
    print(f"Report saved at: {report_path}")


if __name__ == "__main__":
    main()

