
from pathlib import Path
import sys
import json
import numpy as np
import tensorflow as tf
from PIL import Image

# مسیر پروژه
BASE_DIR = Path(__file__).resolve().parent
MODEL_DIR = BASE_DIR / "models"

MODEL_PATH = MODEL_DIR / "best_fruit_model.keras"
CLASS_PATH = MODEL_DIR / "class_names.json"

IMAGE_SIZE = (128, 128)


def predict_fruit(image_path):

    # بررسی وجود مدل
    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            "Trained model not found. Train the model first."
        )

    # بارگذاری مدل آموزش‌دیده
    model = tf.keras.models.load_model(MODEL_PATH)

    # بارگذاری نام کلاس‌ها
    with open(CLASS_PATH, "r", encoding="utf-8") as file:
        class_names = json.load(file)

    # بررسی وجود تصویر
    image_path = Path(image_path)

    if not image_path.exists():
        raise FileNotFoundError(
            f"Image not found: {image_path}"
        )

    # باز کردن و آماده‌سازی تصویر
    image = Image.open(image_path).convert("RGB")
    image = image.resize(IMAGE_SIZE)

    image_array = np.asarray(
        image,
        dtype=np.float32
    )

    # افزودن بعد مربوط به batch
    image_array = np.expand_dims(
        image_array,
        axis=0
    )

    # پیش‌بینی
    probabilities = model.predict(
        image_array,
        verbose=0
    )[0]

    predicted_index = int(np.argmax(probabilities))
    predicted_class = class_names[predicted_index]
    confidence = float(probabilities[predicted_index])

    print("\nFruit Recognition Result")
    print("------------------------------")
    print(f"Predicted fruit: {predicted_class}")
    print(f"Confidence: {confidence * 100:.2f}%")

    print("\nAll class probabilities:")

    for name, probability in zip(class_names, probabilities):
        print(f"{name}: {probability * 100:.2f}%")

    return predicted_class


if __name__ == "__main__":

    if len(sys.argv) < 2:
        print(
            'Usage: python predict_fruit.py "path_to_image.jpg"'
        )
    else:
        predict_fruit(sys.argv[1])
